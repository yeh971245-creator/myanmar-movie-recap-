# Myanmar Movie Recap AI v2.1

Video Upload → transcription → original Burmese recap script → Burmese TTS → Burmese subtitles → MP4.

Required Render Environment Variable: OPENAI_API_KEY
Optional: OPENAI_MODEL, OPENAI_TTS_VOICE

The server burns Burmese subtitles into the output video using bundled Noto Sans Myanmar.
For practical Render use, start with short/medium clips. Long full movies can exceed hosting/API time, storage, or cost limits.
Use only footage you have permission to process and publish.
