import express from "express";
import OpenAI from "openai";
import multer from "multer";
import ffmpegPath from "ffmpeg-static";
import { spawn } from "child_process";
import fs from "fs";
import fsp from "fs/promises";
import path from "path";
import os from "os";
import crypto from "crypto";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = Number(process.env.PORT || 3000);
const textModel = process.env.OPENAI_MODEL || "gpt-6-luna";
const uploadDir = path.join(os.tmpdir(), "recap-mm-v2");
await fsp.mkdir(uploadDir, { recursive: true });

const upload = multer({
  dest: uploadDir,
  limits: { fileSize: 500 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = /^video\/(mp4|quicktime|x-matroska|webm)$/.test(file.mimetype) || /\.(mp4|mov|mkv|webm)$/i.test(file.originalname);
    cb(ok ? null : new Error("MP4/MOV/MKV/WEBM video only"), ok);
  }
});

app.use(express.json({ limit: "2mb" }));
app.use(express.static(__dirname));

function runFFmpeg(args) {
  return new Promise((resolve, reject) => {
    const p = spawn(ffmpegPath, args);
    let stderr = "";
    p.stderr.on("data", d => stderr += d.toString());
    p.on("error", reject);
    p.on("close", code => code === 0 ? resolve() : reject(new Error(stderr.slice(-5000))));
  });
}

function getDuration(file) {
  return new Promise((resolve, reject) => {
    const p = spawn(ffmpegPath, ["-i", file, "-f", "null", "-"]);
    let stderr = "";
    p.stderr.on("data", d => stderr += d.toString());
    p.on("error", reject);
    p.on("close", () => {
      const m = stderr.match(/Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/);
      if (!m) return reject(new Error("Audio duration မဖတ်နိုင်ပါ။"));
      resolve(Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]));
    });
  });
}

function srtTime(sec) {
  const ms = Math.max(0, Math.round(sec * 1000));
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  const x = ms % 1000;
  return `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")},${String(x).padStart(3,"0")}`;
}

function subtitleLines(text, maxChars = 42) {
  const tokens = text.trim().split(/(?<=[။!?])\s+|\s+/);
  const lines = [];
  let cur = "";
  for (const token of tokens) {
    if (!cur) cur = token;
    else if ((cur + " " + token).length <= maxChars) cur += " " + token;
    else { lines.push(cur); cur = token; }
  }
  if (cur) lines.push(cur);
  const out = [];
  for (let i = 0; i < lines.length; i += 2) out.push(lines.slice(i, i + 2).join("\n"));
  return out;
}

async function extractAudio(video, dir) {
  const out = path.join(dir, "audio.mp3");
  await runFFmpeg(["-y", "-i", video, "-vn", "-ac", "1", "-ar", "16000", "-b:a", "64k", out]);
  return out;
}

async function splitAudio(audio, dir) {
  const pattern = path.join(dir, "part-%03d.mp3");
  await runFFmpeg(["-y", "-i", audio, "-f", "segment", "-segment_time", "540", "-reset_timestamps", "1", "-c:a", "libmp3lame", "-b:a", "64k", pattern]);
  const files = (await fsp.readdir(dir)).filter(x => /^part-\d+\.mp3$/.test(x)).sort().map(x => path.join(dir, x));
  return files.length ? files : [audio];
}

async function transcribeParts(parts, client) {
  const texts = [];
  for (const part of parts) {
    const result = await client.audio.transcriptions.create({
      file: fs.createReadStream(part),
      model: "gpt-4o-mini-transcribe",
      prompt: "Movie dialogue. Preserve names and important plot details. Source may be Chinese, English, or mixed language."
    });
    texts.push(result.text || "");
  }
  return texts.join("\n");
}

function chunkText(text, max = 3600) {
  const chunks = [];
  let rest = text.trim();
  while (rest.length > max) {
    let cut = rest.lastIndexOf("။", max);
    if (cut < max * .55) cut = rest.lastIndexOf(".", max);
    if (cut < max * .55) cut = rest.lastIndexOf(" ", max);
    if (cut < max * .55) cut = max;
    chunks.push(rest.slice(0, cut + 1));
    rest = rest.slice(cut + 1).trim();
  }
  if (rest) chunks.push(rest);
  return chunks;
}

async function makeRecap(transcript, client) {
  const response = await client.responses.create({
    model: textModel,
    instructions: "You are a Myanmar movie recap writer. Turn the supplied movie transcript into an original Burmese-language recap narration. Do not reproduce movie dialogue verbatim. Summarize events in your own words, keep important twists, follow chronology, and do not invent facts. Return only the Burmese narration script.",
    input: `Movie transcript:\n\n${transcript}`
  });
  return response.output_text || "";
}

async function makeVoiceAndSubtitles(script, dir, client) {
  const parts = chunkText(script, 3600);
  const audioFiles = [];
  const durations = [];
  for (let i = 0; i < parts.length; i++) {
    const speech = await client.audio.speech.create({
      model: "gpt-4o-mini-tts",
      voice: process.env.OPENAI_TTS_VOICE || "marin",
      input: parts[i],
      instructions: "Speak Burmese naturally as a clear, engaging movie recap narrator. Medium pace, expressive but easy to understand.",
      response_format: "mp3"
    });
    const out = path.join(dir, `voice-${String(i).padStart(3,"0")}.mp3`);
    await fsp.writeFile(out, Buffer.from(await speech.arrayBuffer()));
    audioFiles.push(out);
    durations.push(await getDuration(out));
  }

  const list = path.join(dir, "voice-list.txt");
  await fsp.writeFile(list, audioFiles.map(f => `file '${f.replaceAll("'", "'\\''")}'`).join("\n"));
  const voice = path.join(dir, "voice.mp3");
  await runFFmpeg(["-y", "-f", "concat", "-safe", "0", "-i", list, "-c:a", "libmp3lame", "-b:a", "128k", voice]);

  const srt = path.join(dir, "burmese.srt");
  const entries = [];
  let global = 0, number = 1;
  for (let i = 0; i < parts.length; i++) {
    const subs = subtitleLines(parts[i]);
    const weights = subs.map(s => Math.max(1, s.replace(/\n/g, "").length));
    const total = weights.reduce((a,b) => a + b, 0);
    let t = global;
    for (let j = 0; j < subs.length; j++) {
      const d = durations[i] * weights[j] / total;
      entries.push(`${number++}\n${srtTime(t)} --> ${srtTime(t + Math.max(0.3, d - 0.05))}\n${subs[j]}\n`);
      t += d;
    }
    global += durations[i];
  }
  await fsp.writeFile(srt, entries.join("\n"), "utf8");
  return { voice, srt };
}

async function muxRecap(video, voice, srt, dir) {
  const output = path.join(dir, "myanmar-recap.mp4");
  const subtitlePath = srt.replaceAll("\\", "/").replaceAll(":", "\\:");
  const fontDir = __dirname.replaceAll("\\", "/").replaceAll(":", "\\:");
  const vf = `subtitles=${subtitlePath}:fontsdir=${fontDir}:force_style='FontName=Noto Sans Myanmar,FontSize=20,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,Outline=3,Shadow=1,MarginV=55,Alignment=2'`;
  await runFFmpeg([
    "-y", "-stream_loop", "-1", "-i", video, "-i", voice,
    "-map", "0:v:0", "-map", "1:a:0", "-vf", vf,
    "-c:v", "libx264", "-preset", "veryfast", "-crf", "24",
    "-c:a", "aac", "-b:a", "128k", "-shortest", "-movflags", "+faststart", output
  ]);
  return output;
}

const clean = dir => fsp.rm(dir, { recursive: true, force: true }).catch(() => {});

app.get("/health", (_req, res) => res.json({ ok: true, model: textModel, version: "2.1.0" }));

app.post("/api/recap", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) throw new Error("OPENAI_API_KEY မရှိသေးပါ။");
    const { story, style = "မြန်မာ Storytelling", length = "Medium" } = req.body ?? {};
    if (!story?.trim()) return res.status(400).json({ error: "Story / Notes ထည့်ပါ။" });
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.responses.create({
      model: textModel,
      instructions: "Write an original Burmese movie recap narration from supplied notes. Do not reproduce copyrighted dialogue verbatim.",
      input: `Style: ${style}\nLength: ${length}\n\nMovie story / notes:\n${story.trim()}`
    });
    res.json({ script: response.output_text || "" });
  } catch (err) { res.status(500).json({ error: err.message || "Recap failed" }); }
});

app.post("/api/process-video", upload.single("video"), async (req, res) => {
  const job = path.join(uploadDir, crypto.randomUUID());
  await fsp.mkdir(job, { recursive: true });
  try {
    if (!process.env.OPENAI_API_KEY) throw new Error("OPENAI_API_KEY မရှိသေးပါ။ Render Environment Variables ထဲထည့်ပါ။");
    if (!req.file) throw new Error("Video ဖိုင်ရွေးပါ။");
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const video = path.join(job, "source" + path.extname(req.file.originalname || ".mp4"));
    await fsp.rename(req.file.path, video);
    const audio = await extractAudio(video, job);
    const parts = await splitAudio(audio, job);
    const transcript = await transcribeParts(parts, client);
    if (!transcript.trim()) throw new Error("Video အသံကို စာအဖြစ်မဖတ်နိုင်ပါ။");
    const script = await makeRecap(transcript, client);
    if (!script.trim()) throw new Error("Recap script မထွက်လာပါ။");
    const voice = await makeVoiceAndSubtitles(script, job, client);
    await muxRecap(video, voice.voice, voice.srt, job);
    res.json({ ok: true, token: path.basename(job), script, download: `/api/download/${path.basename(job)}` });
  } catch (err) {
    console.error(err);
    await clean(job);
    if (req.file?.path) await fsp.rm(req.file.path, { force: true }).catch(() => {});
    res.status(500).json({ error: err.message || "Video processing failed" });
  }
});

app.get("/api/download/:token", async (req, res) => {
  const dir = path.join(uploadDir, req.params.token);
  const file = path.join(dir, "myanmar-recap.mp4");
  try { await fsp.access(file); res.download(file, "myanmar-recap.mp4", () => clean(dir)); }
  catch { res.status(404).json({ error: "Video မတွေ့တော့ပါ။" }); }
});

app.listen(port, "0.0.0.0", () => console.log(`Recap MM v2.1 running on port ${port}`));
