# Recap MM AI v1.3

## Run
1. Install Node.js.
2. Run `npm install`
3. Set `OPENAI_API_KEY` as an environment variable.
4. Optional: set `OPENAI_MODEL` (default: `gpt-6-luna`).
5. Run `npm start`
6. Open `http://localhost:3000`

Do not put the API key in HTML or client-side JavaScript.

The `/api/recap` endpoint accepts:
{
  "story": "movie story or notes",
  "style": "မြန်မာ Storytelling",
  "length": "Medium"
}
